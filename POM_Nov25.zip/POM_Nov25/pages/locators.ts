

export const locators = {

  "usernameField": "#username",
  "PwdField":"#password",
  "login_logout":".decorativeSubmit",
  "crmLink":"//a[contains(text(),'CRM')]",
"LeadMod":"//a[text()='Leads']"

} 