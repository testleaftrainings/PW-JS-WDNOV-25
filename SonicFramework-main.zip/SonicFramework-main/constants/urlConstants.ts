export enum URLConstants {
    adminURL = "https://login.salesforce.com/"
}